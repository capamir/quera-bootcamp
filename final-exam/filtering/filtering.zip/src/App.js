import './App.css'
import Students from "./components/Students";

function App() {
  return (
    <Students />
  );
}

export default App;
